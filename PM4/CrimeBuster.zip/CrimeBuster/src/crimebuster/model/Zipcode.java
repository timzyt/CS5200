package crimebuster.model;

public class Zipcode {

  protected String zipcode;

  public Zipcode(String zipcode) {
    this.zipcode = zipcode;
  }

  public String getZipcode() {
    return zipcode;
  }

  public void setZipcode(String zipcode) {
    this.zipcode = zipcode;
  }
}
