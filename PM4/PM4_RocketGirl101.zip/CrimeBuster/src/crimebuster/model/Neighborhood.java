package crimebuster.model;

public class Neighborhood {

  protected String neighborhood;

  public Neighborhood(String neighborhood) {
    this.neighborhood = neighborhood;
  }

  public String getNeighborhood() {
    return neighborhood;
  }

  public void setNeighborhood(String neighborhood) {
    this.neighborhood = neighborhood;
  }
}
